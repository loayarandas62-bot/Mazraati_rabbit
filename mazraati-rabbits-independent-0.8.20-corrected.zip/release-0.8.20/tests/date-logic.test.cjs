const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const src = fs.readFileSync(require('path').join(__dirname, '..', 'app.js'), 'utf8');
const validDateLine = src.match(/^const validDate=.*;$/m)?.[0];
const dateAddLine = src.match(/^const dateAdd=.*;$/m)?.[0];
const todayLine = src.match(/^const today=.*;$/m)?.[0];
const ageLine = src.match(/^function age\(b\).*$/m)?.[0];
const validDateTimeLine = src.match(/^const validDateTime=.*;$/m)?.[0];
const matingValidationLine = src.match(/^const matingValidation=.*;$/m)?.[0];
const normalizeImportedBlock = src.match(/^function normalizeImported\(d\)\{[\s\S]*?^\}/m)?.[0];
assert(validDateLine && dateAddLine && todayLine && ageLine && validDateTimeLine && matingValidationLine && normalizeImportedBlock, 'date, mating, and import helpers exist');
const context = {};
vm.createContext(context);
vm.runInContext(`${todayLine}\n${validDateLine}\n${validDateTimeLine}\n${dateAddLine}\n${matingValidationLine}\n${ageLine}\nconst fresh=()=>({rabbits:[],matings:[],litters:[],reminders:[],alerts:[],expenses:[],sales:[]});\n${normalizeImportedBlock}\nthis.api={validDate,validDateTime,dateAdd,matingValidation,age,today,normalizeImported};`, context);
const { validDate, validDateTime, dateAdd, matingValidation, age, today, normalizeImported } = context.api;
assert.equal(validDate('2024-02-29'), true);
assert.equal(validDate('2026-02-29'), false);
assert.equal(validDate('2026-02-30'), false);
assert.equal(validDateTime('2026-11-23T19:05'), true);
assert.equal(validDateTime('2026-02-30T19:05'), false);
assert.equal(validDateTime('2026-11-23T24:00'), false);
assert.equal(validDateTime('2026-11-23 19:05'), false);
assert.equal(dateAdd('2026-01-31', 30), '2026-03-02');
assert.equal(dateAdd('2024-02-01', 30), '2024-03-02');
assert.equal(dateAdd('2024-02-29', 30), '2024-03-30');
assert.equal(dateAdd('2026-12-15', 30), '2027-01-14');

const rabbitsForMating = [
  { id: 'f1', sex: 'أنثى' },
  { id: 'm1', sex: 'ذكر' },
  { id: 'f2', sex: 'أنثى', archived: true },
  { id: 'x1', sex: 'غير محدد' }
];
assert.equal(matingValidation('f1', 'm1', today(), rabbitsForMating, []), '');
assert.match(matingValidation('', 'm1', today(), rabbitsForMating, []), /اختر أنثى/);
assert.match(matingValidation('m1', '', today(), rabbitsForMating, []), /اختر أنثى/);
assert.match(matingValidation('f2', '', today(), rabbitsForMating, []), /اختر أنثى/);
assert.match(matingValidation('f1', 'x1', today(), rabbitsForMating, []), /الذكر المختار/);
assert.match(matingValidation('f1', '', '2026-02-30', rabbitsForMating, []), /تاريخ التزاوج/);
assert.match(matingValidation('f1', '', '2999-01-01', rabbitsForMating, []), /تاريخ التزاوج/);
assert.match(matingValidation('f1', '', today(), rabbitsForMating, [{ female: 'f1', done: false }]), /تزاوج غير منتهٍ/);
assert.equal(matingValidation('f1', '', today(), rabbitsForMating, [{ female: 'f1', done: true }]), '');
assert.throws(() => dateAdd('2026-02-30', 30));
assert.throws(() => normalizeImported({}), 'empty object must not be accepted as a backup');
assert.throws(() => normalizeImported({rabbits:[],matings:[{id:'m1',female:'missing',date:today(),due:dateAdd(today(),30),done:false}]}), 'mating cannot reference a missing female');
assert.throws(() => normalizeImported({rabbits:[{id:'r1',name:'',sex:'أنثى'}],matings:[]}), 'rabbit name is required');
assert.throws(() => normalizeImported({rabbits:[{id:'r1',name:'أم',sex:'أنثى'}],matings:[{id:'m1',female:'r1',date:today(),due:dateAdd(today(),29),done:false}]}), 'expected birth date must be 30 days after mating');
assert.throws(() => normalizeImported({rabbits:[{id:'r1',name:'أم',sex:'أنثى'}],matings:[{id:'m1',female:'r1',male:'ghost',date:today(),due:dateAdd(today(),30),done:false}]}), 'male reference must exist');
const imported = normalizeImported({rabbits:[{id:'r1',name:'أم',sex:'أنثى'}],matings:[]});

const validMother = {id:'mother',name:'أم',sex:'أنثى'};
const validFather = {id:'father',name:'أب',sex:'ذكر'};
const validLitter = {id:'l1',mother:'mother',father:'father',date:today(),count:2};
assert.throws(() => normalizeImported({rabbits:[validMother],matings:[],litters:[{...validLitter,mother:'ghost'}]}), 'litter must reference an existing mother');
assert.throws(() => normalizeImported({rabbits:[validMother],matings:[],litters:[{...validLitter,count:0}]}), 'litter count must be positive');
assert.throws(() => normalizeImported({rabbits:[{...validMother,weights:[{value:-5,date:today()}]}],matings:[]}), 'weight must be positive');
assert.throws(() => normalizeImported({rabbits:[{...validMother,weights:[{value:1500,date:'2026-02-30'}]}],matings:[]}), 'weight date must be a real calendar date');
assert.throws(() => normalizeImported({rabbits:[validMother],matings:[],expenses:[{id:'e1',item:'علف',amount:-1,date:today()}]}), 'expense amount must be positive');
assert.throws(() => normalizeImported({rabbits:[validMother],matings:[],reminders:[{id:'r1',title:'موعد',at:'2026-11-23 19:00',seen:false}]}), 'reminder must use a valid date-time');
assert.throws(() => normalizeImported({rabbits:[{...validMother,litterId:'ghost'}],matings:[]}), 'kit cannot reference a missing litter');

const linkedKit = {id:'kit1',name:'صغير',sex:'غير محدد',litterId:'l1',parentIds:{mother:'mother',father:'father'}};
const validLinkedBackup = normalizeImported({rabbits:[validMother,validFather,{...linkedKit}],matings:[],litters:[validLitter]});
assert.equal(validLinkedBackup.litters[0].count, 2, 'valid litter and parent links are retained');
assert.throws(() => normalizeImported({rabbits:[validMother,validFather],matings:[],litters:[{...validLitter,father:'ghost'}]}), 'litter must not reference a missing father');


assert.equal(imported.rabbits[0].weights.length, 0, 'older backups receive missing history defaults');
assert.deepEqual(Object.keys(imported).sort(), ['alerts','expenses','litters','matings','reminders','rabbits','sales'].sort());
assert.throws(() => dateAdd('2026-01-01', 1.5));
assert.equal(age(''), 'غير مسجل');
assert.equal(age('2999-01-01'), 'لم يولد بعد');
assert.equal(age('2999-02-30'), 'تاريخ غير صالح');
assert.equal(age('2026-02-30'), 'تاريخ غير صالح');
assert.match(age(today()), /0 يوم/);
const todayDate = new Date(today() + 'T12:00:00Z');
const iso = d => d.toISOString().slice(0, 10);
const oneYearAgo = new Date(Date.UTC(todayDate.getUTCFullYear()-1, todayDate.getUTCMonth(), todayDate.getUTCDate()));
assert.match(age(iso(oneYearAgo)), /1 سنة/);
const twoMonthsAgo = new Date(Date.UTC(todayDate.getUTCFullYear(), todayDate.getUTCMonth()-2, todayDate.getUTCDate()));
assert.match(age(iso(twoMonthsAgo)), /2 شهر/);
assert.match(src.match(/^function renderAlerts\(\).*$/m)?.[0] || '', /filter\(m=>!m\.done&&!m\.seen\)/, 'birth alert stays visible until acknowledged');
assert.match(src, /تاريخ الفطام يجب أن يكون صحيحاً بين تاريخ الميلاد واليوم/);
assert.match(src, /تاريخ نقل صحيحاً ليس في المستقبل/);
assert.match(src, /تاريخ بداية صحيحاً ليس في المستقبل/);
assert.match(src, /قبل بداية الحالة/);
assert.match(src.match(/function renderAlerts\(\).*$/m)?.[0] || '', /reminders\.filter\(r=>!r\.seen\)/, 'acknowledged personal reminders are hidden');
assert.match(src, /function checkDueAlarms\(\)/, 'due reminders and births are checked automatically');
assert.match(src.match(/^function checkDueAlarms\(\).*$/m)?.[0] || '', /filter\(m=>!m\.done&&!m\.seen&&validDate\(m\.due\)/, 'acknowledged birth alerts stop sounding');
assert.match(src, /setInterval\(checkDueAlarms,15000\)/, 'alarm checks run while the app is open');
assert.match(src, /function playAlarm\(\)/, 'audible in-app alarm exists');
assert.match(src, /now-lastAlarmAt>=60000/, 'unacknowledged due alerts repeat at a limited interval');
assert.match(src, /أدخل عنواناً وموعداً صحيحاً للتذكير/);
assert.match(src, /تاريخاً صحيحاً ليس في المستقبل/);
assert.match(src, /تاريخاً تقويمياً صحيحاً ليس في المستقبل/);
assert.match(src, /هذا الاسم أو الرقم مسجل من قبل/);
assert.match(src, /تاريخ الميلاد يجب أن يكون صحيحاً وليس في المستقبل/);
assert.match(src, /active.filter\(r=>r.sex==='أنثى'\)/);
assert.match(src, /active.filter\(r=>r.sex==='ذكر'\)/);
assert.match(src.match(/\$\('birthForm'\)\.onsubmit=.*$/m)?.[0] || '', /date<mating\.date/, 'birth date cannot precede mating');
assert.match(src, /matingValidation\(female,male,date,db\.rabbits,db\.matings\)/, 'mating form validates female, male, date, and duplicate active mating');
assert.match(src, /invalid backup structure/, 'backup imports require a valid data structure');
assert.match(src, /missing or invalid mating female/, 'backup imports reject broken parent references');
console.log('Date and alert logic tests passed');
