const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

const line = prefix => app.split('\n').find(value => value.startsWith(prefix)) || '';

test('recording illness appends a dated health entry and marks the same rabbit as sick', () => {
  const handler = line(" $('healthForm').onsubmit=");
  assert.ok(handler, 'health form handler exists');
  assert.match(handler, /r\.healthHistory\.push\(\{id:uid\(\),symptoms,date,action:\$\('healthAction'\)\.value\.trim\(\),recovered:null\}\)/);
  assert.match(handler, /r\.statusHistory\.push\(\{from:r\.status,to:'مريض',date\}\)/);
  assert.match(handler, /r\.status='مريض'/);
  assert.match(handler, /if\(save\(\)\)detail\(r\)/);
});

test('recovery closes the latest open health entry without deleting earlier history', () => {
  const handler = line(" $('recoverForm').onsubmit=");
  assert.ok(handler, 'recovery form handler exists');
  assert.match(handler, /\.slice\(\)\.reverse\(\)\.find\(x=>!x\.recovered\)/);
  assert.match(handler, /if\(open\)open\.recovered=date/);
  assert.match(handler, /r\.statusHistory\.push\(\{from:r\.status,to:'سليم',date\}\)/);
  assert.match(handler, /r\.status='سليم'/);
  assert.doesNotMatch(handler, /healthHistory\s*=\s*\[\]/);
});

test('health history validates symptoms and dates, including recovery chronology', () => {
  const illness = line(" $('healthForm').onsubmit=");
  const recovery = line(" $('recoverForm').onsubmit=");
  assert.match(illness, /!symptoms\|\|!validDate\(date\)\|\|date>today\(\)/);
  assert.match(recovery, /date<open\.date/);
  assert.match(app, /typeof h\.symptoms!=='string'\|\|!h\.symptoms\.trim\(\)/);
  assert.match(app, /h\.recovered\&&!validDate\(h\.recovered\)/);
});
