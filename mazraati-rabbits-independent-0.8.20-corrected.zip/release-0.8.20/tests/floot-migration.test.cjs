const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { convertFlootBackup } = require('../scripts/floot-migration.cjs');

const sample = () => ({
  app: 'mazraati-rabbits', schemaVersion: 1, exportedAt: '2026-11-28T08:00:00.000Z',
  data: {
    rabbits: [
      { id: 1, name: 'أم فستق', sex: 'أنثى', cage: 'C1', status: 'سليم', birthDate: '2025-01-01' },
      { id: 2, name: 'فحل', sex: 'ذكر', cage: 'C2', status: 'سليم' },
      { id: 3, name: 'صغير', sex: 'غير محدد', cage: 'C1', status: 'سليم', birthDate: '2026-11-19', motherId: 1, fatherId: 2 }
    ],
    breedings: [{ id: 10, femaleId: 1, maleId: 2, date: '2026-10-20', outcome: 'تمت الولادة', done: true, history: [], actualBirth: '2026-11-19' }],
    cageMoves: [{ id: 1, rabbitId: 1, from: 'C0', to: 'C1', date: '2026-11-01' }],
    births: [{ id: 20, femaleId: 1, maleId: 2, date: '2026-11-19', count: 1, notes: 'ولادة سليمة' }],
    healthRecords: [{ id: 1, rabbitId: 1, date: '2026-11-21', symptoms: 'خمول', action: 'متابعة', status: 'سليم' }],
    weightRecords: [{ id: 1, rabbitId: 1, date: '2026-11-22', grams: 1800 }],
    financeRecords: [{ id: 1, kind: 'مصروف', date: '2026-11-22', amount: 15, category: 'علف', notes: '' }, { id: 2, kind: 'مبيع', date: '2026-11-23', amount: 50, category: 'بيع', notes: '' }],
    reminders: [{ id: 1, title: 'تنظيف', date: '2026-11-29', notes: '', done: false }],
    acknowledgedDueIds: ['due-10'], archive: [{ rabbit: { id: 9, name: 'مباع', sex: 'ذكر', cage: 'C9', status: 'سليم' }, reason: 'مباع', date: '2026-11-10', notes: 'بيع' }]
  }
});

test('converts Floot collections and preserves IDs/relationships', () => {
  const out = convertFlootBackup(sample());
  assert.equal(out.rabbits.length, 4);
  assert.equal(out.rabbits.find(r => r.id === '3').parentIds.mother, '1');
  assert.equal(out.rabbits.find(r => r.id === '3').litterId, '20');
  assert.equal(out.matings[0].due, '2026-11-19');
  assert.equal(out.matings[0].seen, true);
  assert.equal(out.litters[0].matingId, '10');
  assert.deepEqual(out.rabbits.find(r => r.id === '1').birthHistory, [{ date: '2026-11-19', count: 1, litterId: '20' }]);
  assert.equal(out.rabbits.find(r => r.id === '1').lastBirth, '2026-11-19');
  assert.equal(out.rabbits.find(r => r.id === '1').cageHistory[0].from, 'C0');
  assert.equal(out.rabbits.find(r => r.id === '1').healthHistory[0].symptoms, 'خمول');
  assert.equal(out.rabbits.find(r => r.id === '1').weights[0].value, 1800);
  assert.equal(out.expenses[0].amount, 15);
  assert.equal(out.sales[0].amount, 50);
  assert.equal(out.reminders[0].at, '2026-11-29T09:00');
  assert.equal(out.rabbits.find(r => r.id === '9').archived, true);
  assert.equal(out.migration.sourceBackup.data.rabbits.length, 3);
});

test('rejects an unknown backup envelope', () => {
  assert.throws(() => convertFlootBackup({ app: 'wrong', schemaVersion: 1, data: {} }));
});

test('does not mutate the supplied backup', () => {
  const input = sample();
  const before = JSON.stringify(input);
  convertFlootBackup(input);
  assert.equal(JSON.stringify(input), before);
});


test('rejects impossible calendar dates instead of normalizing them', () => {
  const input = sample();
  input.data.rabbits[0].birthDate = '2026-02-31';
  input.data.breedings[0].date = '2026-02-31';
  const out = convertFlootBackup(input);
  assert.equal(out.rabbits.find(r => r.id === '1').birth, '');
  assert.equal(out.matings.length, 0);
  assert.ok(out.migration.warnings.some(w => w.includes('تاريخ الميلاد غير صالح')));
});

test('skips duplicate rabbit identifiers and keeps the first record', () => {
  const input = sample();
  input.data.rabbits.push({ id: '1', name: 'نسخة مكررة', sex: 'أنثى' });
  const out = convertFlootBackup(input);
  assert.equal(out.rabbits.filter(r => r.id === '1').length, 1);
  assert.equal(out.rabbits.find(r => r.id === '1').name, 'أم فستق');
});

test('does not create a litter for a male or missing mother', () => {
  const input = sample();
  input.data.births.push({ id: 21, femaleId: 2, maleId: 1, date: '2026-11-20', count: 2 });
  const out = convertFlootBackup(input);
  assert.equal(out.litters.length, 1);
  assert.ok(out.migration.warnings.some(w => w.includes('سجل ولادة غير مكتمل')));
});

test('filters invalid weights and invalid actual-birth dates while preserving source backup', () => {
  const input = sample();
  input.data.weightRecords.push({ id: 2, rabbitId: 1, date: '2026-11-22', grams: 'Infinity' });
  input.data.breedings[0].actualBirth = '2026-02-31';
  const out = convertFlootBackup(input);
  assert.equal(out.rabbits.find(r => r.id === '1').weights.length, 1);
  assert.equal(out.matings[0].actualBirth, undefined);
  assert.equal(out.migration.sourceBackup.data.weightRecords.length, 2);
});


test('converted backup passes the independent app actual import validator', () => {
  const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const start = app.indexOf('function normalizeImported(d){');
  const end = app.indexOf('\nfunction activeRabbits()', start);
  assert.ok(start >= 0 && end > start, 'could not locate the app import validator');
  const validatorSource = app.slice(start, end);
  const validDate = date => {
    if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
    const [y,m,d] = date.split('-').map(Number), v = new Date(Date.UTC(y,m-1,d));
    return v.getUTCFullYear() === y && v.getUTCMonth() === m-1 && v.getUTCDate() === d;
  };
  const validDateTime = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value) && validDate(value.split('T')[0]) && Number(value.slice(11,13)) <= 23 && Number(value.slice(14,16)) <= 59;
  const dateAdd = (date, days) => { const d = new Date(`${date}T00:00:00Z`); d.setUTCDate(d.getUTCDate()+days); return d.toISOString().slice(0,10); };
  const normalize = new Function('fresh','validDate','dateAdd','validDateTime', `${validatorSource}; return normalizeImported;`) (
    () => ({rabbits:[],matings:[],litters:[],reminders:[],alerts:[],expenses:[],sales:[]}), validDate, dateAdd, validDateTime
  );
  const converted = convertFlootBackup(sample());
  const accepted = normalize(converted);
  assert.equal(accepted.rabbits.length, 4);
  assert.equal(accepted.matings.length, 1);
  assert.equal(accepted.litters.length, 1);
  assert.equal(accepted.expenses.length, 1);
  assert.equal(accepted.sales.length, 1);
});


test('does not misclassify unknown finance kinds as expenses', () => {
  const input = sample();
  input.data.financeRecords.push({ id: 3, kind: 'تحويل', date: '2026-11-24', amount: 99, category: 'غير معروف' });
  const out = convertFlootBackup(input);
  assert.equal(out.expenses.length, 1);
  assert.equal(out.sales.length, 1);
  assert.ok(out.migration.warnings.some(w => w.includes('نوع غير معروف')));
  assert.equal(out.migration.sourceBackup.data.financeRecords.length, 3);
});

test('does not link a female or missing rabbit as a litter father', () => {
  const input = sample();
  input.data.births[0].maleId = 1;
  const out = convertFlootBackup(input);
  assert.equal(out.litters[0].father, undefined);
  assert.ok(out.migration.warnings.some(w => w.includes('الأب غير موجود أو جنسه غير صحيح')));
});

test('removes invalid parent-sex relationships while preserving the original source', () => {
  const input = sample();
  input.data.rabbits[2].motherId = 2;
  const out = convertFlootBackup(input);
  assert.equal(out.rabbits.find(r => r.id === '3').parentIds.mother, undefined);
  assert.ok(out.migration.warnings.some(w => w.includes('مرجع الأم غير موجود أو جنسه غير صحيح')));
  assert.equal(out.migration.sourceBackup.data.rabbits[2].motherId, 2);
});


test('preserves every valid litter in the mother production history and selects latest date', () => {
  const input = sample();
  input.data.births.push({ id: 22, femaleId: 1, maleId: 2, date: '2026-11-25', count: 3, notes: 'ولادة ثانية' });
  input.data.births.push({ id: 23, femaleId: 1, maleId: 2, date: '2026-02-31', count: 2 });
  const out = convertFlootBackup(input);
  const mother = out.rabbits.find(r => r.id === '1');
  assert.equal(out.litters.length, 2);
  assert.deepEqual(mother.birthHistory.map(x => x.litterId), ['20', '22']);
  assert.equal(mother.lastBirth, '2026-11-25');
  assert.equal(out.migration.sourceBackup.data.births.length, 3);
});


test('does not guess a kit litter when the same mother has multiple litters on the same date', () => {
  const input = sample();
  input.data.births.push({ id: 21, femaleId: 1, maleId: 2, date: '2026-11-19', count: 2, notes: 'سجل إضافي في اليوم نفسه' });
  const out = convertFlootBackup(input);
  const kit = out.rabbits.find(r => r.id === '3');
  assert.equal(out.litters.length, 2);
  assert.equal(kit.litterId, undefined);
  assert.ok(out.migration.warnings.some(w => w.includes('أكثر من ولادة للأم في تاريخ الميلاد نفسه')));
  assert.equal(out.rabbits.find(r => r.id === '1').birthHistory.length, 2);
});


test('does not guess a litter mating when several matching breeding records precede birth', () => {
  const input = sample();
  input.data.breedings.push({ id: 11, femaleId: 1, maleId: 2, date: '2026-10-25', outcome: 'تمت الولادة', done: true, history: [], actualBirth: '2026-11-19' });
  const out = convertFlootBackup(input);
  assert.equal(out.litters[0].matingId, undefined);
  assert.ok(out.migration.warnings.some(w => w.includes('عدة سجلات تزاوج محتملة')));
  assert.equal(out.migration.sourceBackup.data.breedings.length, 2);
});
