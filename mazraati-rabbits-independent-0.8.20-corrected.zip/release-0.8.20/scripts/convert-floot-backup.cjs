'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { convertFlootBackup } = require('./floot-migration.cjs');
const [input, output] = process.argv.slice(2);
if (!input || !output) {
  process.stderr.write('الاستخدام: node scripts/convert-floot-backup.cjs <floot-backup.json> <independent-backup.json>\n');
  process.exit(2);
}
try {
  const payload = JSON.parse(fs.readFileSync(input, 'utf8'));
  const converted = convertFlootBackup(payload);
  fs.writeFileSync(output, JSON.stringify(converted, null, 2) + '\n', { flag: 'wx' });
  const count = key => Array.isArray(converted[key]) ? converted[key].length : 0;
  process.stdout.write(`تم إنشاء نسخة التحويل: ${path.resolve(output)}\n`);
  process.stdout.write(`الأرانب: ${count('rabbits')} | التزاوج: ${count('matings')} | الولادات: ${count('litters')} | المصاريف: ${count('expenses')} | المبيعات: ${count('sales')}\n`);
  process.stdout.write(`ملاحظات المراجعة: ${converted.migration.warnings.length}\n`);
  if (converted.migration.warnings.length) converted.migration.warnings.forEach((w, i) => process.stdout.write(`${i + 1}. ${w}\n`));
  process.stdout.write('احتُفظ بملف Floot الأصلي كاملاً داخل migration.sourceBackup. لا تستورد قبل مراجعة التحذيرات والاحتفاظ بنسخة أمان.\n');
} catch (error) {
  process.stderr.write(`فشل التحويل: ${error.message}\n`);
  process.exit(1);
}
