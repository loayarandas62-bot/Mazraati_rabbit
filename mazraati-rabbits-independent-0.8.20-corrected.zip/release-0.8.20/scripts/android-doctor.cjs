const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const checks = [
  ['Node.js', 'node', ['--version']],
  ['npm', 'npm', ['--version']],
  ['Java', 'java', ['-version']],
  ['Gradle', 'gradle', ['--version']],
  ['ADB', 'adb', ['version']],
  ['Android SDK Manager', 'sdkmanager', ['--version']],
];
let missing = 0;
console.log('فحص بيئة بناء مزرعتي للأرانب\n');
for (const [label, command, args] of checks) {
  const result = spawnSync(command, args, { encoding: 'utf8', timeout: 8000 });
  const ok = !result.error && result.status === 0;
  if (!ok) missing++;
  const output = `${result.stdout || ''}${result.stderr || ''}`.trim().split(/\r?\n/)[0];
  console.log(`${ok ? '✓' : '✗'} ${label}${ok && output ? ` — ${output}` : ''}`);
}
const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
console.log(`${sdk && fs.existsSync(sdk) ? '✓' : '✗'} مسار Android SDK${sdk ? ` — ${sdk}` : ' — غير مضبوط'}`);
if (!sdk || !fs.existsSync(sdk)) missing++;
console.log(`${fs.existsSync(path.join(root, 'android', 'gradlew')) ? '✓' : '✗'} مشروع Android/Gradle Wrapper${fs.existsSync(path.join(root, 'android', 'gradlew')) ? '' : ' — لم يُنشأ بعد'}`);
if (!fs.existsSync(path.join(root, 'android', 'gradlew'))) missing++;
console.log(`\nالنتيجة: ${missing === 0 ? 'البيئة تبدو جاهزة للمتابعة.' : `هناك ${missing} متطلب/متطلبات ناقصة. راجع ANDROID_BUILD_GUIDE_AR.md.`}`);
process.exitCode = missing === 0 ? 0 : 1;
