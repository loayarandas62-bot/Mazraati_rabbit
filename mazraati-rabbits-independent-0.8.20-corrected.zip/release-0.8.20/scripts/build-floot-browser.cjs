'use strict';
const fs = require('node:fs');
const source = fs.readFileSync('scripts/floot-migration.cjs', 'utf8');
const browser = source.replace("module.exports = { convertFlootBackup };", "window.convertFlootBackup = convertFlootBackup;");
if (browser === source) throw new Error('لم يتم العثور على نقطة تصدير محوّل Floot.');
fs.writeFileSync('floot-migration.js', browser);
process.stdout.write('تم إنشاء floot-migration.js للمتصفح.\n');
