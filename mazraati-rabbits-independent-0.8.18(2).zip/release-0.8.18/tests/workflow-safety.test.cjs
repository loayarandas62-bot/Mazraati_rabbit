const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const app = fs.readFileSync('app.js', 'utf8');
const sw = fs.readFileSync('sw.js', 'utf8');
const pkg = require('../package.json');

test('mating workflow supports the three agreed statuses and closes unsuccessful attempts', () => {
  for (const status of ['بانتظار الفحص', 'حامل', 'لم يحدث حمل']) assert.ok(app.includes(status));
  assert.match(app, /item\.outcome==='لم يحدث حمل'\)\{item\.done=true/);
  assert.match(app, /m\.female===femaleId&&!m\.done&&\(m\.outcome\|\|'بانتظار الفحص'\)!=='لم يحدث حمل'/);
});

test('archive is restricted to sale or death and keeps prior status and cage for restoration', () => {
  assert.match(app, /!\['تم بيعه','نافق'\]\.includes\(value\)/);
  assert.match(app, /r\.statusBeforeArchive=r\.status/);
  assert.match(app, /r\.status=r\.statusBeforeArchive\|\|'سليم'/);
  assert.match(app, /r\.cageBeforeArchive=r\.cage;r\.cage=''/);
});

test('failed save rolls in-memory data back to the last successfully saved snapshot', () => {
  assert.match(app, /lastSavedDb=JSON\.parse\(JSON\.stringify\(db\)\)/);
  assert.match(app, /db=JSON\.parse\(JSON\.stringify\(lastSavedDb\)\)/);
});

test('patch release advances offline cache namespace', () => {
  assert.equal(pkg.version, '0.8.18');
  assert.match(sw, /mazraati-rabbits-\$\{CACHE_PREFIX\}v25|CACHE_NAME = `\$\{CACHE_PREFIX\}v25`/);
});


test('test-data reset requires confirmation, backs up first, and clears only app records', () => {
  assert.match(app, /\$\('resetDataBtn'\)\.onclick/);
  assert.match(app, /نسخة أمان قبل إعادة ضبط بيانات التجربة/);
  assert.match(app, /if\(!confirm\(/);
  assert.match(app, /db=fresh\(\)/);
  assert.match(app, /if\(save\(\)\)alert\('تمت إعادة ضبط بيانات التجربة بنجاح/);
  assert.match(fs.readFileSync('index.html', 'utf8'), /id="resetDataBtn"/);
  assert.match(fs.readFileSync('index.html', 'utf8'), /النسخ الاحتياطية المحفوظة/);
});

test('corrupt local storage is preserved and blocks all writes instead of silently starting over', () => {
  assert.match(app, /const CORRUPT_KEY='mazraati_rabbits_corrupt_recovery_v1'/);
  assert.match(app, /storageLoadError=err/);
  assert.match(app, /localStorage\.setItem\(CORRUPT_KEY,raw\)/);
  assert.match(app, /if\(storageLoadError\)\{alert\(/);
  assert.match(app, /!storageLoadError&&localStorage\.getItem\(KEY\)/);
});
