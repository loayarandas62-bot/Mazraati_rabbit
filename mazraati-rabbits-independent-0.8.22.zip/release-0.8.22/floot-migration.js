'use strict';

const datePattern = /^\d{4}-\d{2}-\d{2}$/;
const asId = value => value === null || value === undefined || value === '' ? '' : String(value);
const migrationValidDate = value => {
  if (typeof value !== 'string' || !datePattern.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
};
const datePlus30 = value => {
  if (!migrationValidDate(value)) return '';
  const d = new Date(`${value}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 30);
  return d.toISOString().slice(0, 10);
};
const list = (data, key) => {
  const value = data[key];
  if (value === undefined) return [];
  if (!Array.isArray(value)) throw new Error(`مجموعة غير صالحة: ${key}`);
  return value;
};

/** Convert a Floot schemaVersion=1 backup into the independent app's schema.
 * Original Floot payload is retained verbatim under migration.sourceBackup.
 * No input object is mutated. Warnings enumerate records needing human review.
 */
function convertFlootBackup(payload) {
  if (!payload || payload.app !== 'mazraati-rabbits' || payload.schemaVersion !== 1 || !payload.data || typeof payload.data !== 'object') {
    throw new Error('ملف Floot غير معروف أو إصدار النسخة غير مدعوم.');
  }
  const src = payload.data;
  const rabbits = list(src, 'rabbits');
  const breedings = list(src, 'breedings');
  const cageMoves = list(src, 'cageMoves');
  const births = list(src, 'births');
  const health = list(src, 'healthRecords');
  const weights = list(src, 'weightRecords');
  const finance = list(src, 'financeRecords');
  const reminders = list(src, 'reminders');
  const archive = list(src, 'archive');
  const acknowledged = list(src, 'acknowledgedDueIds');
  const warnings = [];

  const mapRabbit = (r, archived = false, archiveEntry = null) => {
    if (!r || typeof r !== 'object' || r.id === undefined || !asId(r.id).trim() || !String(r.name || '').trim()) {
      warnings.push('توجد بطاقة أرنب ناقصة المعرّف أو الاسم؛ لم تُحوّل.');
      return null;
    }
    const id = asId(r.id);
    const rabbit = {
      id, name: String(r.name), sex: ['ذكر', 'أنثى', 'غير محدد'].includes(r.sex) ? r.sex : 'غير محدد',
      status: r.status || 'سليم', breed: r.breed || '', cage: r.cage || '',
      birth: migrationValidDate(r.birthDate) ? r.birthDate : '', notes: r.notes || '', weights: [], cageHistory: [], healthHistory: [], statusHistory: [],
      parentIds: {},
      createdAt: r.createdAt || payload.exportedAt || new Date(0).toISOString()
    };
    if (r.birthDate && !migrationValidDate(r.birthDate)) warnings.push(`الأرنب ${id}: تاريخ الميلاد غير صالح؛ لم يُنقل هذا الحقل.`);
    if (r.weaningDate && migrationValidDate(r.weaningDate) && rabbit.birth && r.weaningDate >= rabbit.birth) rabbit.weaningDate = r.weaningDate;
    else if (r.weaningDate) warnings.push(`الأرنب ${id}: تاريخ الفطام يحتاج مراجعة؛ لم يُنقل.`);
    for (const [role, parent] of [['mother', r.motherId], ['father', r.fatherId]]) if (parent !== undefined && parent !== null && String(parent) !== '') rabbit.parentIds[role] = asId(parent);
    if (archived) {
      rabbit.archived = true;
      rabbit.archiveReason = archiveEntry.reason || 'مباع';
      rabbit.statusBeforeArchive = rabbit.status;
      rabbit.status = rabbit.archiveReason;
      rabbit.archivedAt = archiveEntry.date || '';
      rabbit.archiveDate = archiveEntry.date || '';
      rabbit.cageBeforeArchive = rabbit.cage;
      rabbit.cage = '';
      rabbit.archiveNotes = archiveEntry.notes || '';
    }
    return rabbit;
  };

  const mappedRabbits = [];
  const seenRabbitIds = new Set();
  for (const sourceRabbit of rabbits) {
    const mapped = mapRabbit(sourceRabbit);
    if (!mapped) continue;
    if (seenRabbitIds.has(mapped.id)) { warnings.push(`معرّف الأرنب ${mapped.id} مكرر؛ احتُفظ بأول سجل فقط.`); continue; }
    seenRabbitIds.add(mapped.id); mappedRabbits.push(mapped);
  }
  const archiveIds = new Set(mappedRabbits.map(r => r.id));
  for (const entry of archive) {
    if (!entry || !entry.rabbit) { warnings.push('سجل أرشيف غير مكتمل؛ احتُفظ به في النسخة المصدرية فقط.'); continue; }
    const id = asId(entry.rabbit.id);
    if (!id.trim()) { warnings.push('سجل أرشيف بلا معرّف؛ احتُفظ به في النسخة المصدرية فقط.'); continue; }
    if (archiveIds.has(id)) { warnings.push(`الأرنب ${id} موجود في النشط والأرشيف معاً؛ لم نكرر سجله المؤرشف.`); continue; }
    const r = mapRabbit(entry.rabbit, true, entry);
    if (r) { mappedRabbits.push(r); archiveIds.add(id); }
  }
  const rabbitIds = new Set(mappedRabbits.map(r => r.id));
  for (const rabbit of mappedRabbits) {
    for (const role of ['mother', 'father']) {
      const parentId = rabbit.parentIds[role];
      const parent = parentId ? mappedRabbits.find(item => item.id === parentId) : null;
      const expectedSex = role === 'mother' ? 'أنثى' : 'ذكر';
      if (parentId && (!parent || parent.sex !== expectedSex)) {
        warnings.push(`الأرنب ${rabbit.id}: مرجع ${role === 'mother' ? 'الأم' : 'الأب'} غير موجود أو جنسه غير صحيح؛ لم يُنقل هذا الربط.`);
        delete rabbit.parentIds[role];
      }
    }
  }

  const mappedMatings = [];
  const seenMatingIds = new Set();
  for (const b of breedings) {
    if (!b || typeof b !== 'object' || !asId(b.id).trim() || seenMatingIds.has(asId(b.id))) { warnings.push(`سجل تزاوج ناقص أو مكرر (المعرّف ${asId(b?.id)})؛ احتُفظ به في النسخة المصدرية فقط.`); continue; }
    const female = asId(b.femaleId), male = asId(b.maleId);
    const femaleRecord = mappedRabbits.find(r => r.id === female);
    if (!femaleRecord || femaleRecord.sex !== 'أنثى') { warnings.push(`التزاوج ${b.id}: الأنثى غير موجودة أو جنسها غير صحيح؛ احتُفظ به في النسخة المصدرية فقط.`); continue; }
    if (!migrationValidDate(b.date)) { warnings.push(`التزاوج ${b.id}: تاريخ غير صالح؛ احتُفظ به في النسخة المصدرية فقط.`); continue; }
    if (male && (!rabbitIds.has(male) || mappedRabbits.find(r => r.id === male)?.sex !== 'ذكر')) warnings.push(`التزاوج ${b.id}: الذكر ${male} غير موجود أو جنسه غير صحيح؛ نُقل التزاوج دون ربط ذكر غير صالح.`);
    const outcome = ['بانتظار الفحص', 'حامل', 'لم يحدث حمل', 'تمت الولادة'].includes(b.outcome) ? b.outcome : 'بانتظار الفحص';
    if (b.outcome && outcome !== b.outcome) warnings.push(`التزاوج ${b.id}: الحالة غير معروفة؛ عُيّنت «بانتظار الفحص».`);
    const id = asId(b.id); seenMatingIds.add(id);
    const done = Boolean(b.done);
    const actualBirth = migrationValidDate(b.actualBirth) && b.actualBirth >= b.date && done ? b.actualBirth : undefined;
    if (b.actualBirth && !actualBirth) warnings.push(`التزاوج ${b.id}: تاريخ الولادة الفعلية غير متوافق؛ لم يُنقل هذا الحقل.`);
    mappedMatings.push({ id, female, ...(male && rabbitIds.has(male) && mappedRabbits.find(r => r.id === male)?.sex === 'ذكر' ? { male } : {}), date: b.date, due: datePlus30(b.date), done, outcome, history: Array.isArray(b.history) ? b.history : [], ...(actualBirth ? { actualBirth } : {}), seen: acknowledged.includes(`due-${b.id}`) });
  }


  const mappedLitters = [];
  for (const b of births) {
    const mother = mappedRabbits.find(r => r.id === asId(b?.femaleId));
    if (!b || !asId(b.id).trim() || !mother || mother.sex !== 'أنثى' || !migrationValidDate(b.date) || !Number.isInteger(Number(b.count)) || Number(b.count) < 1 || Number(b.count) > 30) {
      warnings.push(`سجل ولادة غير مكتمل أو غير صالح (المعرّف ${asId(b?.id)})؛ احتُفظ به في النسخة المصدرية فقط.`);
      continue;
    }
    const father = mappedRabbits.find(r => r.id === asId(b.maleId));
    if (b.maleId !== undefined && b.maleId !== null && String(b.maleId) !== '' && (!father || father.sex !== 'ذكر')) warnings.push(`الولادة ${b.id}: الأب غير موجود أو جنسه غير صحيح؛ نُقلت الولادة دون ربط أب.`);
    const relatedCandidates = mappedMatings.filter(m => m.female === asId(b.femaleId) && m.male === asId(b.maleId) && m.date <= b.date);
    const related = relatedCandidates.length === 1 ? relatedCandidates[0] : null;
    if (relatedCandidates.length > 1) warnings.push(`الولادة ${asId(b.id)}: توجد عدة سجلات تزاوج محتملة للأم والأب قبل تاريخ الولادة؛ تُرك الربط دون تخمين.`);
    if (mappedLitters.some(x => x.id === asId(b.id))) { warnings.push(`معرّف الولادة ${asId(b.id)} مكرر؛ لم يُكرر السجل.`); continue; }
    mappedLitters.push({ id: asId(b.id), mother: asId(b.femaleId), ...(father?.sex === 'ذكر' ? { father: father.id } : {}), date: b.date, count: Number(b.count), ...(related ? { matingId: related.id } : {}), notes: b.notes || '' });
  }
  const littersByBirth = new Map();
  for (const litter of mappedLitters) {
    const key = `${litter.mother}|${litter.date}`;
    const group = littersByBirth.get(key) || [];
    group.push(litter);
    littersByBirth.set(key, group);
  }
  // Keep the mother's production history as well as the litter records.
  // The independent app uses birthHistory/lastBirth in the female profile.
  for (const litter of mappedLitters) {
    const mother = mappedRabbits.find(r => r.id === litter.mother);
    if (!mother) continue;
    mother.birthHistory ||= [];
    mother.birthHistory.push({ date: litter.date, count: litter.count, litterId: litter.id });
    if (!mother.lastBirth || litter.date > mother.lastBirth) mother.lastBirth = litter.date;
  }
  for (const r of mappedRabbits) {
    const candidates = littersByBirth.get(`${r.parentIds?.mother || ''}|${r.birth || ''}`) || [];
    if (candidates.length === 1 && r.parentIds?.father === (candidates[0].father || '')) r.litterId = candidates[0].id;
    else if (candidates.length > 1 && r.parentIds?.mother) warnings.push(`الأرنب ${r.id}: توجد أكثر من ولادة للأم في تاريخ الميلاد نفسه؛ لم يُربط بصندوق ولادة محدد لتجنب ربط خاطئ.`);
  }

  for (const m of cageMoves) {
    const rabbit = mappedRabbits.find(r => r.id === asId(m?.rabbitId));
    if (rabbit && migrationValidDate(m.date)) rabbit.cageHistory.push({ from: m.from || '', to: m.to || '', date: m.date });
    else warnings.push(`انتقال قفص غير مكتمل للأرنب ${asId(m?.rabbitId)}؛ راجع النسخة المصدرية.`);
  }
  for (const h of health) {
    const rabbit = mappedRabbits.find(r => r.id === asId(h?.rabbitId));
    if (rabbit && migrationValidDate(h.date)) rabbit.healthHistory.push({ date: h.date, symptoms: h.symptoms || 'غير موضح', action: h.action || '', status: h.status || '' });
    else warnings.push(`سجل صحي غير مكتمل للأرنب ${asId(h?.rabbitId)}؛ راجع النسخة المصدرية.`);
  }
  for (const w of weights) {
    const rabbit = mappedRabbits.find(r => r.id === asId(w?.rabbitId));
    if (rabbit && migrationValidDate(w.date) && Number.isFinite(Number(w.grams)) && Number(w.grams) > 0) rabbit.weights.push({ date: w.date, value: Number(w.grams) });
    else warnings.push(`قياس وزن غير مكتمل للأرنب ${asId(w?.rabbitId)}؛ راجع النسخة المصدرية.`);
  }

  const expenses = [], sales = [];
  const seenFinanceIds = { expenses: new Set(), sales: new Set() };
  for (const x of finance) {
    if (!x || !migrationValidDate(x.date) || !Number.isFinite(Number(x.amount)) || Number(x.amount) <= 0) { warnings.push('حركة مالية غير صالحة؛ بقيت في النسخة المصدرية.'); continue; }
    if (!asId(x.id).trim()) { warnings.push('حركة مالية بلا معرّف؛ بقيت في النسخة المصدرية.'); continue; }
    if (x.kind !== 'مبيع' && x.kind !== 'مصروف') { warnings.push(`الحركة المالية ${asId(x.id)}: نوع غير معروف؛ لم تُصنّف كمصروف أو مبيع وبقيت في النسخة المصدرية.`); continue; }
    const group = x.kind === 'مبيع' ? 'sales' : 'expenses';
    const id = asId(x.id);
    if (seenFinanceIds[group].has(id)) { warnings.push(`معرّف حركة مالية ${id} مكرر؛ بقي التكرار في النسخة المصدرية.`); continue; }
    seenFinanceIds[group].add(id);
    const item = { id, item: String(x.category || 'غير مصنف'), amount: Number(x.amount), date: x.date, notes: x.notes || '' };
    (group === 'sales' ? sales : expenses).push(item);
  }
  const mappedReminders = [];
  const seenReminderIds = new Set();
  for (const r of reminders) {
    const id = asId(r?.id);
    if (!r || !id.trim() || seenReminderIds.has(id) || !r.title || !migrationValidDate(r.date)) { warnings.push('تذكير ناقص أو مكرر أو بتاريخ غير صالح؛ بقي في النسخة المصدرية.'); continue; }
    seenReminderIds.add(id); mappedReminders.push({ id, title: String(r.title), at: `${r.date}T09:00`, seen: Boolean(r.done), notes: r.notes || '' });
  }
  if (reminders.length !== mappedReminders.length) warnings.push('بعض التذكيرات لم تحمل تاريخاً صالحاً؛ راجع النسخة المصدرية.');

  return {
    rabbits: mappedRabbits, matings: mappedMatings, litters: mappedLitters, reminders: mappedReminders,
    alerts: [], expenses, sales,
    migration: { from: 'floot-mazraati-rabbits-schema-v1', convertedAt: new Date().toISOString(), warnings, sourceBackup: payload }
  };
}

window.convertFlootBackup = convertFlootBackup;
