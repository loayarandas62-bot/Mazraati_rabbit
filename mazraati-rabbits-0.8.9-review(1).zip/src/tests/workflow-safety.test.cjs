const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const app = fs.readFileSync('app.js', 'utf8');
const sw = fs.readFileSync('sw.js', 'utf8');
const pkg = require('../package.json');

test('mating workflow supports the three agreed statuses and closes unsuccessful attempts', () => {
  for (const status of ['بانتظار الفحص', 'حامل', 'لم يحدث حمل']) assert.ok(app.includes(status));
  assert.match(app, /item\.outcome==='لم يحدث حمل'\)\{item\.done=true/);
  assert.match(app, /m\.female===femaleId&&!m\.done&&\(m\.outcome\|\|'بانتظار الفحص'\)!=='لم يحدث حمل'/);
});

test('archive is restricted to sale or death and keeps prior status and cage for restoration', () => {
  assert.match(app, /!\['تم بيعه','نافق'\]\.includes\(value\)/);
  assert.match(app, /r\.statusBeforeArchive=r\.status/);
  assert.match(app, /r\.status=r\.statusBeforeArchive\|\|'سليم'/);
  assert.match(app, /r\.cageBeforeArchive=r\.cage;r\.cage=''/);
});

test('failed save rolls in-memory data back to the last successfully saved snapshot', () => {
  assert.match(app, /lastSavedDb=JSON\.parse\(JSON\.stringify\(db\)\)/);
  assert.match(app, /db=JSON\.parse\(JSON\.stringify\(lastSavedDb\)\)/);
});

test('patch release advances offline cache namespace', () => {
  assert.equal(pkg.version, '0.8.9');
  assert.match(sw, /mazraati-rabbits-\$\{CACHE_PREFIX\}v17|CACHE_NAME = `\$\{CACHE_PREFIX\}v17`/);
});
