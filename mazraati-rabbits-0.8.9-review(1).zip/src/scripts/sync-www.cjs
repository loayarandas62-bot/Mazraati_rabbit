const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const target = path.join(root, 'www');
const files = ['index.html', 'styles.css', 'app.js', 'sw.js', 'manifest.webmanifest'];
fs.mkdirSync(target, { recursive: true });
for (const file of files) {
  fs.copyFileSync(path.join(root, file), path.join(target, file));
}
console.log(`Synced ${files.length} web assets into www/`);
