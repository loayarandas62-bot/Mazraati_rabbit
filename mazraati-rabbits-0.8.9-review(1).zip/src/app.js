const KEY='mazraati_rabbits_v1';
const BACKUP_KEY='mazraati_rabbits_backups_v1';
const MAX_BACKUPS=10;
const $=id=>document.getElementById(id);
const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const validDate=date=>{if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date))return false;const [y,m,d]=date.split('-').map(Number),v=new Date(Date.UTC(y,m-1,d));return v.getUTCFullYear()===y&&v.getUTCMonth()===m-1&&v.getUTCDate()===d};
const validDateTime=value=>{if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value))return false;const [date,time]=value.split('T');if(!validDate(date))return false;const [h,m]=time.split(':').map(Number);return h>=0&&h<=23&&m>=0&&m<=59};
const dateAdd=(date,days)=>{if(!validDate(date)||!Number.isInteger(days))throw Error('تاريخ غير صالح');const [y,m,d]=date.split('-').map(Number),base=new Date(Date.UTC(y,m-1,d));base.setUTCDate(base.getUTCDate()+days);return `${base.getUTCFullYear()}-${String(base.getUTCMonth()+1).padStart(2,'0')}-${String(base.getUTCDate()).padStart(2,'0')}`};
const matingValidation=(femaleId,maleId,date,rabbits,matings)=>{const female=rabbits.find(r=>r.id===femaleId&&!r.archived);if(!female||female.sex!=='أنثى')return 'اختر أنثى مسجلة ونشطة.';if(maleId){const male=rabbits.find(r=>r.id===maleId&&!r.archived);if(!male||male.sex!=='ذكر')return 'الذكر المختار غير صحيح أو غير نشط.'}if(!validDate(date)||date>today())return 'تاريخ التزاوج يجب أن يكون صحيحاً واليوم أو تاريخاً سابقاً.';if(matings.some(m=>m.female===femaleId&&!m.done&&(m.outcome||'بانتظار الفحص')!=='لم يحدث حمل'))return 'لدى هذه الأنثى سجل تزاوج غير منتهٍ وما زال قيد المتابعة. حدّد نتيجته أولاً.';return ''};
const uid=()=>crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random());
const esc=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function fresh(){return {rabbits:[],matings:[],litters:[],reminders:[],alerts:[],expenses:[],sales:[]}}
function load(){try{const d=JSON.parse(localStorage.getItem(KEY))||fresh();for(const k of Object.keys(fresh()))if(!Array.isArray(d[k]))d[k]=[];d.rabbits.forEach(r=>{r.weights ||= [];r.cageHistory ||= [];r.healthHistory ||= [];r.statusHistory ||= [];r.parentIds ||= {};});if(!Array.isArray(d.litters))d.litters=[];return d}catch{return fresh()}}
let db=load();
let lastSavedDb=JSON.parse(JSON.stringify(db));
function readBackups(){try{const x=JSON.parse(localStorage.getItem(BACKUP_KEY)||'[]');return Array.isArray(x)?x.filter(b=>b&&typeof b.data==='string'&&b.id):[]}catch{return []}}
function makeBackup(data,reason='حفظ تلقائي'){
 const raw=JSON.stringify(data),list=readBackups();
 if(list.length&&list[list.length-1].data===raw)return;
 list.push({id:uid(),at:new Date().toISOString(),reason,data:raw});
 // إذا اقتربت مساحة التخزين من الامتلاء، نقلّل عدد النسخ تدريجياً مع إبقاء أحدث نسخة.
 for(let keep=Math.min(MAX_BACKUPS,list.length);keep>=1;keep--){
  try{localStorage.setItem(BACKUP_KEY,JSON.stringify(list.slice(-keep)));return}
  catch(err){if(keep===1)throw err}
 }
}
function save(){
 const raw=JSON.stringify(db);
 try{
  // تُكتب نسخة الاسترداد أولاً؛ إذا فشل النسخ لا نستبدل سجل البيانات الأساسي بصمت.
  makeBackup(db);
  localStorage.setItem(KEY,raw);
  lastSavedDb=JSON.parse(raw);
 }catch(err){
  db=JSON.parse(JSON.stringify(lastSavedDb));
  alert('تعذّر إكمال الحفظ الآمن. أُعيدت البيانات في الذاكرة إلى آخر نسخة محفوظة بنجاح. صدّر نسخة JSON أو حرّر مساحة ثم حاول مجدداً.');
  render();
  return false;
 }
 render();if($('backupList'))renderBackups();return true;
}
function renderBackups(){const list=readBackups().slice().reverse();$('backupList').innerHTML=list.length?list.map(b=>`<article class="rabbit-card"><div><h3>${esc(new Date(b.at).toLocaleString('ar'))}</h3><div class="muted">${esc(b.reason)} · ${(()=>{try{return JSON.parse(b.data).rabbits?.length||0}catch{return 0}})()} أرنب</div></div><button class="small-btn" data-backup-restore="${b.id}">استعادة</button></article>`).join(''):'<div class="empty">لا توجد نسخ محفوظة بعد.</div>'}
function exportBackup(data=db){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`نسخة-مزرعتي-${today()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function normalizeImported(d){
 if(!d||typeof d!=='object'||Array.isArray(d)||!Array.isArray(d.rabbits)||!Array.isArray(d.matings))throw Error('invalid backup structure');
 for(const k of Object.keys(fresh()))if(d[k]===undefined&&['litters','reminders','alerts','expenses','sales'].includes(k))d[k]=[];else if(!Array.isArray(d[k]))throw Error('invalid backup collection');
 const ids=new Set();
 for(const r of d.rabbits){if(!r||typeof r!=='object'||Array.isArray(r)||typeof r.id!=='string'||!r.id.trim()||typeof r.name!=='string'||!r.name.trim()||!['ذكر','أنثى','غير محدد'].includes(r.sex))throw Error('invalid rabbit record');if(ids.has(r.id))throw Error('duplicate rabbit id');ids.add(r.id);if(r.birth&& !validDate(r.birth))throw Error('invalid rabbit birth date');r.weights ||= [];r.cageHistory ||= [];r.healthHistory ||= [];r.statusHistory ||= [];r.parentIds ||= {};if(!Array.isArray(r.weights)||!Array.isArray(r.cageHistory)||!Array.isArray(r.healthHistory)||!Array.isArray(r.statusHistory)||typeof r.parentIds!=='object'||Array.isArray(r.parentIds))throw Error('invalid rabbit history')}
 const matingIds=new Set();
 for(const m of d.matings){if(!m||typeof m!=='object'||Array.isArray(m)||typeof m.id!=='string'||!m.id.trim()||matingIds.has(m.id)||typeof m.female!=='string'||!m.female.trim()||!validDate(m.date)||!validDate(m.due)||m.due!==dateAdd(m.date,30)||typeof m.done!=='boolean'||(m.outcome!==undefined&&!['بانتظار الفحص','حامل','لم يحدث حمل','تمت الولادة'].includes(m.outcome)))throw Error('invalid mating record');matingIds.add(m.id);const female=d.rabbits.find(r=>r.id===m.female);if(!female||female.sex!=='أنثى')throw Error('missing or invalid mating female');if(m.male){const male=d.rabbits.find(r=>r.id===m.male);if(!male||male.sex!=='ذكر')throw Error('missing or invalid mating male')}if(m.actualBirth&&(!validDate(m.actualBirth)||m.actualBirth<m.date||!m.done))throw Error('invalid actual birth date')}
 const checkHistoryDate=(item,key='date')=>item&&typeof item==='object'&&!Array.isArray(item)&&validDate(item[key]);
 for(const r of d.rabbits){
  for(const w of r.weights)if(!checkHistoryDate(w)||!Number.isFinite(Number(w.value))||Number(w.value)<=0)throw Error('invalid weight history');
  for(const h of r.cageHistory)if(!checkHistoryDate(h)||typeof h.to!=='string')throw Error('invalid cage history');
  for(const h of r.healthHistory)if(!checkHistoryDate(h)||typeof h.symptoms!=='string'||!h.symptoms.trim()||(h.recovered&&!validDate(h.recovered)))throw Error('invalid health history');
  for(const h of r.statusHistory)if(!checkHistoryDate(h)||typeof h.to!=='string')throw Error('invalid status history');
  if(r.birthHistory!==undefined){if(!Array.isArray(r.birthHistory))throw Error('invalid birth history');for(const h of r.birthHistory)if(!checkHistoryDate(h)||!Number.isInteger(Number(h.count))||Number(h.count)<1)throw Error('invalid birth history item')}
  if(r.weaningDate!==undefined&&r.weaningDate!==null&&(!validDate(r.weaningDate)||!validDate(r.birth)||r.weaningDate<r.birth))throw Error('invalid weaning date');
  if(r.parentIds?.mother&&!ids.has(r.parentIds.mother))throw Error('missing kit mother');if(r.parentIds?.father&&!ids.has(r.parentIds.father))throw Error('missing kit father');
 }
 const litterIds=new Set();
 for(const l of d.litters){if(!l||typeof l!=='object'||Array.isArray(l)||typeof l.id!=='string'||!l.id.trim()||litterIds.has(l.id)||!validDate(l.date)||!Number.isInteger(Number(l.count))||Number(l.count)<1||Number(l.count)>30||!ids.has(l.mother))throw Error('invalid litter record');litterIds.add(l.id);const mother=d.rabbits.find(r=>r.id===l.mother);if(mother.sex!=='أنثى')throw Error('invalid litter mother');if(l.father&&!ids.has(l.father))throw Error('missing litter father');if(l.matingId&&!matingIds.has(l.matingId))throw Error('missing litter mating')}
 for(const r of d.rabbits)if(r.litterId&&!litterIds.has(r.litterId))throw Error('missing rabbit litter');
 for(const group of ['expenses','sales'])for(const item of d[group])if(!item||typeof item!=='object'||Array.isArray(item)||typeof item.id!=='string'||!item.id.trim()||typeof item.item!=='string'||!item.item.trim()||!Number.isFinite(Number(item.amount))||Number(item.amount)<=0||!validDate(item.date))throw Error('invalid finance record');
 const reminderIds=new Set();for(const item of d.reminders){if(!item||typeof item!=='object'||Array.isArray(item)||typeof item.id!=='string'||!item.id.trim()||reminderIds.has(item.id)||typeof item.title!=='string'||!item.title.trim()||!validDateTime(item.at)||typeof item.seen!=='boolean')throw Error('invalid reminder record');reminderIds.add(item.id)}
 return d
}
function age(b){if(!b)return 'غير مسجل';if(!validDate(b))return 'تاريخ غير صالح';const current=today();if(b>current)return 'لم يولد بعد';const [by,bm,bd]=b.split('-').map(Number),[ny,nm,nd]=current.split('-').map(Number);let years=ny-by,months=nm-bm,days=nd-bd;if(days<0){months--;const daysInPreviousMonth=new Date(Date.UTC(ny,nm-1,0)).getUTCDate();days+=daysInPreviousMonth}if(months<0){years--;months+=12}const parts=[];if(years)parts.push(`${years} سنة`);if(months)parts.push(`${months} شهر`);if(days||!parts.length)parts.push(`${days} يوم`);return parts.join(' و ')}
function activeRabbits(){return db.rabbits.filter(r=>!r.archived)}
function render(){const active=activeRabbits();$('totalCount').textContent=active.length;$('femaleCount').textContent=active.filter(r=>r.sex==='أنثى').length;$('maleCount').textContent=active.filter(r=>r.sex==='ذكر').length;$('dueCount').textContent=db.matings.filter(m=>!m.done).length;
 const q=$('searchInput').value.trim().toLowerCase();const list=active.filter(r=>[r.name,r.cage,r.id].some(v=>String(v||'').toLowerCase().includes(q)));
 $('rabbitList').innerHTML=list.length?list.map(r=>`<article class="rabbit-card"><div><h3>${esc(r.name)}</h3><div class="muted">${esc(r.sex)} · ${esc(r.status)} · القفص ${esc(r.cage||'—')} · العمر ${age(r.birth)}</div></div><div class="rabbit-actions"><button class="small-btn" data-detail="${r.id}">السجل</button><button class="small-btn" data-edit="${r.id}">تعديل</button></div></article>`).join(''):'<div class="empty">لا توجد نتائج.</div>';
 $('matingFemale').innerHTML=active.filter(r=>r.sex==='أنثى').map(r=>`<option value="${r.id}">${esc(r.name)}</option>`).join('');$('matingMale').innerHTML='<option value="">غير محدد</option>'+active.filter(r=>r.sex==='ذكر').map(r=>`<option value="${r.id}">${esc(r.name)}</option>`).join('');
 $('matingList').innerHTML=db.matings.length?db.matings.slice().reverse().map(m=>{const f=db.rabbits.find(r=>r.id===m.female),male=db.rabbits.find(r=>r.id===m.male);const left=Math.ceil((new Date(m.due+'T12:00:00')-new Date(today()+'T12:00:00'))/86400000);return `<article class="rabbit-card"><div><h3>${esc(f?.name||'أنثى غير موجودة')}</h3><div class="muted">التزاوج: ${esc(m.date)} · الولادة المتوقعة: ${esc(m.due)} · الذكر: ${esc(male?.name||'غير محدد')}</div></div><div class="rabbit-actions"><span class="muted">${esc(m.outcome||(m.done?'تمت الولادة':'بانتظار الفحص'))}${!m.done&&m.outcome!=='لم يحدث حمل'?` · ${left>=0?`باقي ${left} يوم`:'تجاوز الموعد'}`:''}</span><button class="small-btn" data-mating-status="${m.id}">تحديث الحالة</button><button class="small-btn" data-edit-mating="${m.id}" ${m.done?'disabled':''}>تعديل التاريخ</button></div></article>`}).join(''):'<div class="empty">لا توجد سجلات تزاوج.</div>';
 renderAlerts();renderArchive();renderBirths();renderFinance();renderCages();renderStats();if($('backupList'))renderBackups();}

function renderCages(){
 const groups=new Map();activeRabbits().forEach(r=>{const cage=String(r.cage||'بدون قفص');if(!groups.has(cage))groups.set(cage,[]);groups.get(cage).push(r)});
 const html=[...groups.entries()].sort((a,b)=>a[0].localeCompare(b[0],'ar')).map(([cage,rows])=>`<article class="rabbit-card"><div><h3>القفص ${esc(cage)}</h3><div class="muted">${rows.length} أرنب · ${rows.map(r=>esc(r.name)).join('، ')}</div></div><strong>${rows.length}</strong></article>`).join('');
 $('cageSummary').innerHTML=html||'<div class="empty">لا توجد أرانب مسجلة لعرض الأقفاص.</div>';
 $('cageStats').innerHTML=html||'<div class="empty">لا توجد بيانات أقفاص.</div>';
}
function renderStats(){
 const a=activeRabbits(),pregnant=new Set(db.matings.filter(m=>!m.done).map(m=>m.female)).size;
 const females=a.filter(r=>r.sex==='أنثى').map(r=>{const history=Array.isArray(r.birthHistory)?r.birthHistory:[];return {rabbit:r,births:history.length,kits:history.reduce((n,h)=>n+Number(h.count||0),0)}}).sort((x,y)=>y.births-x.births||y.kits-x.kits||String(x.rabbit.name).localeCompare(String(y.rabbit.name),'ar'));
 $('femaleProduction').innerHTML=females.length?females.map(x=>`<article class="rabbit-card"><div><h3>${esc(x.rabbit.name)}</h3><div class="muted">${x.births} ولادة · ${x.kits} مولوداً مسجلاً</div></div><strong>${x.births} / ${x.kits}</strong></article>`).join(''):'<div class="empty">لا توجد إناث نشطة للمقارنة.</div>';
 const values=[['الإجمالي',a.length],['الإناث',a.filter(r=>r.sex==='أنثى').length],['الذكور',a.filter(r=>r.sex==='ذكر').length],['حوامل/لديهن تزاوج غير منتهٍ',pregnant],['الولادات المتوقعة',db.matings.filter(m=>!m.done).length],['الصغار',a.filter(r=>!!r.litterId).length],['المرضى',a.filter(r=>r.status==='مريض').length],['إجمالي الولادات',db.litters.length]];
 $('statsSummary').innerHTML=values.map(([label,value])=>`<article class="summary"><span>${label}</span><strong>${value}</strong></article>`).join('');
 if(!$('statsFrom').value){const d=new Date();d.setDate(1);$('statsFrom').value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`;}
 if(!$('statsTo').value)$('statsTo').value=today();
}
function calculatePeriod(){const from=$('statsFrom').value,to=$('statsTo').value;if(!from||!to||from>to){$('periodStats').textContent='تحقق من تاريخ البداية والنهاية.';return}const litters=db.litters.filter(l=>l.date>=from&&l.date<=to);const kits=litters.reduce((n,l)=>n+Number(l.count||0),0);$('periodStats').textContent=`خلال الفترة من ${from} إلى ${to}: ${litters.length} ولادة، بإجمالي ${kits} صغير.`;}

function renderFinance(){
 if(!$('financeFrom').value){const d=new Date();d.setDate(1);$('financeFrom').value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`;}
 if(!$('financeTo').value)$('financeTo').value=today();
 const from=$('financeFrom').value,to=$('financeTo').value,valid=validDate(from)&&validDate(to)&&from<=to;
 const sales=db.sales.filter(x=>valid&&x.date>=from&&x.date<=to),expenses=db.expenses.filter(x=>valid&&x.date>=from&&x.date<=to);
 const income=sales.reduce((n,x)=>n+Number(x.amount||0),0),expense=expenses.reduce((n,x)=>n+Number(x.amount||0),0);
 $('incomeTotal').textContent=income.toFixed(2);$('expenseTotal').textContent=expense.toFixed(2);$('netTotal').textContent=(income-expense).toFixed(2);
 const rows=[...db.sales.map(x=>({...x,kind:'sale',label:'مبيعات'})),...db.expenses.map(x=>({...x,kind:'expense',label:'مصروف'}))].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 $('financeList').innerHTML=rows.length?rows.map(x=>`<article class="rabbit-card"><div><h3>${esc(x.item||x.label)}</h3><div class="muted">${esc(x.date)} · ${x.label} · ${esc(x.notes||'—')}</div></div><strong>${x.kind==='sale'?'+':'−'}${Number(x.amount||0).toFixed(2)}</strong></article>`).join(''):'<div class="empty">لا توجد حركات مالية مسجلة.</div>';
 if(!valid)$('netTotal').textContent='تحقق من الفترة';
}

function renderBirths(){
 const eligible=db.matings.filter(m=>!m.done);
 $('birthMating').innerHTML=eligible.map(m=>{const f=db.rabbits.find(r=>r.id===m.female);return `<option value="${m.id}">${esc(f?.name||'أنثى')} · موعد متوقع ${esc(m.due)}</option>`}).join('');
 $('birthMating').disabled=!eligible.length;
 $('birthSave').disabled=!eligible.length;
 $('litterList').innerHTML=db.litters.length?db.litters.slice().reverse().map(l=>{const f=db.rabbits.find(r=>r.id===l.mother);const kits=db.rabbits.filter(r=>r.litterId===l.id);return `<article class="rabbit-card"><div><h3>ولادة ${esc(f?.name||'أم غير موجودة')}</h3><div class="muted">${esc(l.date)} · عدد الخلفة: ${l.count} · الصغار المسجلون: ${kits.length}</div></div><span class="muted">${kits.map(k=>esc(k.name)).join('، ')}</span></article>`}).join(''):'<div class="empty">لا توجد ولادات مسجلة بعد.</div>';
}
function renderAlerts(){const items=[];db.matings.filter(m=>!m.done&&!m.seen).forEach(m=>{const f=db.rabbits.find(r=>r.id===m.female);items.push({id:m.id,title:`موعد ولادة متوقع: ${f?.name||'أنثى'}`,at:m.due,kind:'mating',seen:false})});db.reminders.filter(r=>!r.seen).forEach(r=>items.push({...r,kind:'reminder'}));$('alertList').innerHTML=items.length?items.map(a=>`<article class="rabbit-card"><div><h3>${esc(a.title)}</h3><div class="muted">${esc(a.at)} ${a.seen?'· تمت المشاهدة':'· لم تتم المشاهدة'}</div></div><button class="small-btn" data-seen="${a.id}" data-kind="${a.kind}">اطلعت</button></article>`).join(''):'<div class="empty">لا توجد تنبيهات غير مؤكدة حالياً.</div>'}
let alarmContext=null;let lastAlarmAt=0;let lastAlarmKeys='';
function unlockAlarmAudio(){try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;if(!alarmContext)alarmContext=new AC();if(alarmContext.state==='suspended')alarmContext.resume()}catch(e){}}
function playAlarm(){try{if(!alarmContext||alarmContext.state!=='running')return;const start=alarmContext.currentTime;for(let i=0;i<3;i++){const osc=alarmContext.createOscillator(),gain=alarmContext.createGain();osc.type='sine';osc.frequency.value=880;gain.gain.setValueAtTime(0.0001,start+i*.32);gain.gain.exponentialRampToValueAtTime(.16,start+i*.32+.025);gain.gain.exponentialRampToValueAtTime(.0001,start+i*.32+.2);osc.connect(gain);gain.connect(alarmContext.destination);osc.start(start+i*.32);osc.stop(start+i*.32+.22)}}catch(e){}}
function checkDueAlarms(){const now=Date.now(),due=[];db.matings.filter(m=>!m.done&&!m.seen&&validDate(m.due)&&m.due<=today()).forEach(m=>due.push(`m:${m.id}`));db.reminders.filter(r=>!r.seen&&validDateTime(r.at)&&new Date(r.at).getTime()<=now).forEach(r=>due.push(`r:${r.id}`));const keys=due.sort().join('|');if(keys&&keys!==lastAlarmKeys){lastAlarmKeys=keys;lastAlarmAt=0}if(keys&&now-lastAlarmAt>=60000){playAlarm();lastAlarmAt=now}}
document.addEventListener('pointerdown',unlockAlarmAudio,{passive:true});document.addEventListener('keydown',unlockAlarmAudio);setInterval(checkDueAlarms,15000);document.addEventListener('visibilitychange',()=>{if(!document.hidden){checkDueAlarms();renderAlerts()}});
function renderArchive(){const q=($('archiveSearch')?.value||'').trim().toLowerCase();const rows=db.rabbits.filter(r=>r.archived&&[r.name,r.cage,r.archiveReason].some(v=>String(v||'').toLowerCase().includes(q)));$('archiveList').innerHTML=rows.length?rows.map(r=>`<article class="rabbit-card"><div><h3>${esc(r.name)}</h3><div class="muted">${esc(r.archiveReason||'مؤرشف')} · ${esc(r.archivedAt||'')} · القفص السابق ${esc(r.cageBeforeArchive||r.cage||'—')}</div></div><button class="small-btn" data-restore="${r.id}">استعادة</button></article>`).join(''):'<div class="empty">الأرشيف فارغ.</div>'}
function openRabbit(r){$('dialogTitle').textContent=r?'تعديل سجل الأرنب':'إضافة أرنب';$('rabbitId').value=r?.id||'';$('rabbitName').value=r?.name||'';$('rabbitSex').value=r?.sex||'غير محدد';$('rabbitStatus').value=r?.status||'سليم';$('rabbitBreed').value=r?.breed||'';$('rabbitCage').value=r?.cage||'';$('rabbitBirth').value=r?.birth||'';$('rabbitNotes').value=r?.notes||'';$('rabbitDialog').showModal()}
function detail(r){$('detailTitle').textContent=`سجل ${r.name}`;const weights=r.weights||[];const weightHtml=weights.length?weights.map((w,i)=>{const prev=weights[i-1],diff=prev?w.value-prev.value:null,days=prev?Math.round((new Date(w.date+'T12:00:00')-new Date(prev.date+'T12:00:00'))/86400000):0;const trend=prev?(diff>0?`زيادة ${diff} غ`:diff<0?`نقص ${Math.abs(diff)} غ`:'ثبات الوزن'):'';const average=prev?(days>0?` · متوسط ${diff>0?'+':''}${(diff/days).toFixed(1)} غ/يوم`:days===0?' · القياسان في اليوم نفسه':' · راجع ترتيب التواريخ'):'';return `<div class="weight-row"><span>${esc(w.date)} · ${w.value} غ</span><b>${prev?trend+average:'أول قياس'}</b></div>`}).join(''):'<p class="muted">لا توجد أوزان مسجلة.</p>';
 const cages=(r.cageHistory||[]).slice().reverse().map(x=>`<div class="detail-row">${esc(x.date)}: من القفص ${esc(x.from||'—')} إلى ${esc(x.to||'—')}</div>`).join('')||'<p class="muted">لا توجد انتقالات أقفاص.</p>';
 const health=(r.healthHistory||[]).slice().reverse().map(x=>`<div class="detail-row"><b>${esc(x.date)} · ${esc(x.symptoms)}</b><br>الإجراء: ${esc(x.action||'—')} · ${x.recovered?`التعافي: ${esc(x.recovered)}`:'الحالة: قيد المتابعة'}</div>`).join('')||'<p class="muted">لا يوجد سجل صحي سابق.</p>';
 $('detailContent').innerHTML=`<div class="detail-row"><b>الجنس:</b> ${esc(r.sex)} · <b>الحالة:</b> ${esc(r.status)}</div><div class="detail-row"><b>السلالة:</b> ${esc(r.breed||'—')} · <b>القفص الحالي:</b> ${esc(r.cage||'—')}</div><div class="detail-row"><b>تاريخ الميلاد:</b> ${esc(r.birth||'—')} · <b>العمر:</b> ${age(r.birth)}</div><div class="detail-row"><b>ملاحظات:</b> ${esc(r.notes||'—')}</div>${r.litterId?`<div class="detail-row"><b>الأم:</b> ${esc(db.rabbits.find(x=>x.id===r.parentIds?.mother)?.name||'—')} · <b>الأب:</b> ${esc(db.rabbits.find(x=>x.id===r.parentIds?.father)?.name||'غير محدد')}</div><form id="weanForm" class="form-card"><label>تاريخ الفطام الفعلي<input id="weanDate" type="date" value="${esc(r.weaningDate||'')}"></label><button class="small-btn">حفظ تاريخ الفطام</button></form>`:''}
 <h3>نقل القفص</h3><form id="cageForm" class="form-card"><label>رقم القفص الجديد<input id="newCage" required value="${esc(r.cage||'')}"></label><label>تاريخ النقل<input id="cageDate" type="date" value="${today()}" required></label><button class="primary">حفظ النقل</button></form>${cages}
 <h3>السجل الصحي</h3>${health}<form id="healthForm" class="form-card"><label>الأعراض<input id="healthSymptoms" required placeholder="وصف الأعراض"></label><label>تاريخ بداية الحالة<input id="healthDate" type="date" value="${today()}" required></label><label>الإجراء أو العلاج<input id="healthAction" placeholder="ما تم عمله"></label><button class="primary">تسجيل الحالة الصحية</button></form><form id="recoverForm" class="form-card"><label>تاريخ التحسن/التعافي<input id="recoveryDate" type="date" value="${today()}" required></label><button class="small-btn">تسجيل التعافي وإعادة الحالة إلى سليم</button></form>
 <h3>سجل الأوزان</h3>${weightHtml}<form id="weightForm" class="form-card"><label>الوزن بالغرام<input id="weightValue" type="number" min="1" required></label><label>تاريخ الوزن<input id="weightDate" type="date" value="${today()}" required></label><button class="primary">حفظ الوزن</button></form><button id="archiveRabbit" class="small-btn">أرشفة الأرنب</button>`;
 $('detailDialog').showModal();
 if($('weanForm'))$('weanForm').onsubmit=e=>{e.preventDefault();const date=$('weanDate').value;if(date&&(!validDate(date)||date>today()||date<r.birth)){alert('تاريخ الفطام يجب أن يكون صحيحاً بين تاريخ الميلاد واليوم.');return}r.weaningDate=date||null;if(save())detail(r)};
 $('cageForm').onsubmit=e=>{e.preventDefault();const next=$('newCage').value.trim(),date=$('cageDate').value;if(!next||!validDate(date)||date>today()){alert('أدخل رقم قفص وتاريخ نقل صحيحاً ليس في المستقبل.');return}if(next!==String(r.cage||'')){r.cageHistory ||= [];r.cageHistory.push({from:r.cage||'',to:next,date});r.cage=next;if(save())detail(r)}else detail(r)};
 $('healthForm').onsubmit=e=>{e.preventDefault();const date=$('healthDate').value,symptoms=$('healthSymptoms').value.trim();if(!symptoms||!validDate(date)||date>today()){alert('أدخل الأعراض وتاريخ بداية صحيحاً ليس في المستقبل.');return}r.healthHistory ||= [];r.healthHistory.push({id:uid(),symptoms,date,action:$('healthAction').value.trim(),recovered:null});r.statusHistory ||= [];r.statusHistory.push({from:r.status,to:'مريض',date});r.status='مريض';if(save())detail(r)};
 $('recoverForm').onsubmit=e=>{e.preventDefault();const date=$('recoveryDate').value,open=(r.healthHistory||[]).slice().reverse().find(x=>!x.recovered);if(!validDate(date)||date>today()||(open&&date<open.date)){alert('تاريخ التعافي يجب أن يكون صحيحاً وليس في المستقبل أو قبل بداية الحالة.');return}if(open)open.recovered=date;r.statusHistory ||= [];r.statusHistory.push({from:r.status,to:'سليم',date});r.status='سليم';if(save())detail(r)};
 $('weightForm').onsubmit=e=>{e.preventDefault();const value=Number($('weightValue').value),date=$('weightDate').value;if(!Number.isFinite(value)||value<=0||!validDate(date)||date>today()){alert('أدخل وزناً صحيحاً بالغرام وتاريخاً تقويمياً صحيحاً ليس في المستقبل.');return}r.weights ||= [];r.weights.push({value,date});r.weights.sort((a,b)=>a.date.localeCompare(b.date));if(save())detail(r)};
 $('archiveRabbit').onclick=()=>{const reason=prompt('اكتب سبب الأرشفة فقط: تم بيعه أو نافق','تم بيعه');if(reason===null)return;const value=reason.trim();if(!['تم بيعه','نافق'].includes(value)){alert('الأرشفة مسموحة فقط عند البيع أو النفوق.');return}r.archived=true;r.archiveReason=value;r.statusBeforeArchive=r.status;r.status=value;r.archivedAt=today();r.archiveDate=today();r.cageBeforeArchive=r.cage;r.cage='';if(save())$('detailDialog').close()}}
$('addRabbitBtn').onclick=()=>openRabbit();$('closeDialog').onclick=()=>$('rabbitDialog').close();$('closeDetail').onclick=()=>$('detailDialog').close();$('searchInput').oninput=render;$('archiveSearch').oninput=renderArchive;
$('rabbitForm').onsubmit=e=>{e.preventDefault();const rid=$('rabbitId').value;const data={name:$('rabbitName').value.trim(),sex:$('rabbitSex').value,status:$('rabbitStatus').value,breed:$('rabbitBreed').value.trim(),cage:$('rabbitCage').value.trim(),birth:$('rabbitBirth').value,notes:$('rabbitNotes').value.trim()};if(!data.name){alert('أدخل اسم الأرنب أو رقمه.');return}if(data.birth&&(!validDate(data.birth)||data.birth>today())){alert('تاريخ الميلاد يجب أن يكون صحيحاً وليس في المستقبل.');return}if(db.rabbits.some(x=>x.id!==rid&&String(x.name||'').trim().toLocaleLowerCase()===data.name.toLocaleLowerCase())){alert('هذا الاسم أو الرقم مسجل من قبل. افتح السجل الموجود لتعديله.');return}if(rid){const r=db.rabbits.find(x=>x.id===rid);if(r){if(String(r.cage||'')!==data.cage){r.cageHistory ||= [];r.cageHistory.push({from:r.cage||'',to:data.cage,date:today()})}if(r.status!==data.status){r.statusHistory ||= [];r.statusHistory.push({from:r.status,to:data.status,date:today()})}Object.assign(r,data)}}else db.rabbits.push({id:uid(),...data,weights:[],cageHistory:[],healthHistory:[],statusHistory:[],createdAt:new Date().toISOString()});$('rabbitDialog').close();save()};
$('rabbitList').onclick=e=>{const edit=e.target.closest('[data-edit]'),det=e.target.closest('[data-detail]');if(edit)openRabbit(db.rabbits.find(r=>r.id===edit.dataset.edit));if(det)detail(db.rabbits.find(r=>r.id===det.dataset.detail))};
$('archiveList').onclick=e=>{const b=e.target.closest('[data-restore]');if(!b)return;const r=db.rabbits.find(x=>x.id===b.dataset.restore);if(r){alert('استعادة سجل مؤرشف ستعيده إلى الأرانب النشطة.');r.archived=false;r.archivedAt=null;r.archiveReason='';r.status=r.statusBeforeArchive||'سليم';delete r.statusBeforeArchive;if(!r.cage)r.cage=r.cageBeforeArchive||'';delete r.cageBeforeArchive;save()}};
$('matingDate').value=today();$('matingForm').onsubmit=e=>{e.preventDefault();const female=$('matingFemale').value,male=$('matingMale').value,date=$('matingDate').value,error=matingValidation(female,male,date,db.rabbits,db.matings);if(error){alert(error);return}db.matings.push({id:uid(),female,male,date,due:dateAdd(date,30),done:false,outcome:'بانتظار الفحص',history:[]});if(save())alert('تم حفظ التزاوج وحساب موعد الولادة المتوقع.')};
$('matingList').onclick=e=>{const statusBtn=e.target.closest('[data-mating-status]');if(statusBtn){const item=db.matings.find(x=>x.id===statusBtn.dataset.matingStatus);if(!item)return;const choice=prompt('اكتب حالة التزاوج كما هي: بانتظار الفحص / حامل / لم يحدث حمل',item.outcome||'بانتظار الفحص');if(choice===null)return;const allowed=['بانتظار الفحص','حامل','لم يحدث حمل'];if(!allowed.includes(choice.trim())){alert('الحالة غير صحيحة. اختر: بانتظار الفحص أو حامل أو لم يحدث حمل.');return}item.outcome=choice.trim();if(item.outcome==='لم يحدث حمل'){item.done=true;item.seen=true}else{item.done=false;item.seen=false}save();return}const b=e.target.closest('[data-edit-mating]');if(!b)return;const m=db.matings.find(x=>x.id===b.dataset.editMating);if(!m||m.done)return;const next=prompt('أدخل تاريخ التزاوج الجديد بصيغة YYYY-MM-DD',m.date);if(next===null||next===m.date)return;if(!/^\d{4}-\d{2}-\d{2}$/.test(next)||next>today()){alert('أدخل تاريخاً صحيحاً ليس في المستقبل.');return}try{const due=dateAdd(next,30);m.history||=[];m.history.push({date:m.date,due:m.due,changedAt:today()});m.date=next;m.due=due;m.seen=false;if(save())alert('تم تعديل التزاوج وإعادة حساب موعد الولادة.');}catch{alert('التاريخ غير صالح.')}};
$('birthDate').value=today();$('financeDate').value=today();
$('birthForm').onsubmit=e=>{e.preventDefault();const mating=db.matings.find(m=>m.id===$('birthMating').value);if(!mating)return;const date=$('birthDate').value,count=Number($('birthCount').value);if(!validDate(date)||date>today()||date<mating.date||!Number.isInteger(count)||count<1||count>30){alert('أدخل تاريخ ولادة صحيحاً بين تاريخ التزاوج واليوم، وعدداً صحيحاً من 1 إلى 30.');return}const mother=db.rabbits.find(r=>r.id===mating.female),father=db.rabbits.find(r=>r.id===mating.male);const litterId=uid();const litter={id:litterId,matingId:mating.id,mother:mating.female,father:mating.male,date,count};db.litters.push(litter);for(let i=1;i<=count;i++){db.rabbits.push({id:uid(),name:`${mother?.name||'صغير'}-${date.replaceAll('-','')}-${i}`,sex:'غير محدد',status:'سليم',breed:mother?.breed||'',cage:mother?.cage||'',birth:date,notes:'مولود جديد',weights:[],cageHistory:[],healthHistory:[],statusHistory:[],createdAt:new Date().toISOString(),litterId,parentIds:{mother:mating.female,father:mating.male},weaningDate:null})}mating.done=true;mating.outcome='تمت الولادة';mating.actualBirth=date;mating.litterId=litterId;if(mother){mother.birthHistory ||= [];mother.birthHistory.push({date,count,litterId});mother.lastBirth=date;}save();alert(`تم تسجيل الولادة وإنشاء ${count} سجلاً فردياً للصغار.`);$('birthForm').reset();$('birthDate').value=today()};
$('financeForm').onsubmit=e=>{e.preventDefault();const item={id:uid(),item:$('financeItem').value.trim(),amount:Number($('financeAmount').value),date:$('financeDate').value,notes:$('financeNotes').value.trim()};if(!item.item||!Number.isFinite(item.amount)||item.amount<=0||!validDate(item.date)||item.date>today()){alert('تحقق من البند والمبلغ، وأدخل تاريخاً صحيحاً ليس في المستقبل.');return}if($('financeType').value==='sale')db.sales.push(item);else db.expenses.push(item);if(save()){e.target.reset();$('financeDate').value=today()}};
$('reminderForm').onsubmit=e=>{e.preventDefault();const title=$('reminderTitle').value.trim(),at=$('reminderAt').value;if(!title||!validDateTime(at)){alert('أدخل عنواناً وموعداً صحيحاً للتذكير.');return}db.reminders.push({id:uid(),title,at,seen:false});if(save())e.target.reset()};
$('alertList').onclick=e=>{const b=e.target.closest('[data-seen]');if(!b)return;if(b.dataset.kind==='reminder'){const r=db.reminders.find(x=>x.id===b.dataset.seen);if(r)r.seen=true}else{const m=db.matings.find(x=>x.id===b.dataset.seen);if(m)m.seen=true}save()};
$('statsApply').onclick=calculatePeriod;$('financeApply').onclick=renderFinance;$('backupBtn').onclick=()=>exportBackup();
$('manualBackupBtn').onclick=()=>exportBackup();
$('importBackupBtn').onclick=()=>$('restoreInput').click();
$('restoreInput').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const imported=normalizeImported(JSON.parse(await f.text()));if(!Array.isArray(imported.rabbits)||!Array.isArray(imported.matings))throw Error();if(confirm('سيتم حفظ نسخة أمان من بياناتك الحالية أولاً، ثم استبدالها بالنسخة المختارة. هل توافق؟')){makeBackup(db,'نسخة أمان قبل الاستعادة');db=imported;if(!save())throw Error('save');alert('تمت استعادة النسخة بنجاح.')}}catch{alert('ملف النسخة غير صالح أو تعذر حفظها. لم يتم تأكيد الاستعادة.')}e.target.value=''};
$('backupList').onclick=e=>{const b=e.target.closest('[data-backup-restore]');if(!b)return;const item=readBackups().find(x=>x.id===b.dataset.backupRestore);if(!item)return;if(!confirm('استعادة هذه النسخة؟ سيتم إنشاء نسخة أمان من بياناتك الحالية قبل الاستعادة.'))return;try{const restored=normalizeImported(JSON.parse(item.data));if(!Array.isArray(restored.rabbits)||!Array.isArray(restored.matings))throw Error();makeBackup(db,'نسخة أمان قبل الاستعادة');db=restored;if(save())alert('تمت استعادة النسخة المختارة.')}catch{alert('تعذر استعادة هذه النسخة؛ بياناتك الحالية لم تُستبدل.')}};
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));['rabbits','mating','births','alerts','archive','finance','cages','stats','backups'].forEach(n=>$(n+'Panel').classList.toggle('hidden',n!==b.dataset.tab))});
function speakVoiceAnswer(message){if(!('speechSynthesis'in window)){alert(message);return}speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(message);utterance.lang='ar';speechSynthesis.speak(utterance)}
function parseVoiceFinanceCommand(transcript){
 const t=String(transcript||'').trim();
 if(!/(سجل|أضف|ضيف|احسب|اشتريت|بعت)/.test(t)||!/(مصروف|مصاريف|شراء|علف|إيراد|ايراد|مبيعات|بيع)/.test(t))return null;
 const normalized=t.replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
 const amountMatch=normalized.match(/(?:بمبلغ|مبلغ|بقيمة)\s*(\d+(?:[.,]\d{1,2})?)|(?<![A-Za-z])((?:\d+(?:[.,]\d{1,2})?))\s*(?:شيكل|شواكل|دولار|دولارات)/) || normalized.match(/(?:^|\s)(\d+(?:[.,]\d{1,2})?)\s*$/);
 if(!amountMatch)return {error:'لم ألتقط المبلغ بوضوح. أعد الجملة واذكر المبلغ بالأرقام.'};
 const amountText=amountMatch[1]||amountMatch[2];
 const amount=Number(amountText.replace(',','.'));
 if(!Number.isFinite(amount)||amount<=0)return {error:'المبلغ غير صحيح. أعد المحاولة بمبلغ أكبر من صفر.'};
 const kind=/(إيراد|ايراد|مبيعات|بيع|بعت)/.test(t)?'sale':'expense';
 let item=normalized.replace(amountMatch[0],' ').replace(/^(?:يا)?\s*(?:سجل|أضف|ضيف|احسب|اشتريت|بعت)(?: لي)?\s*/,'').replace(/(?:مصروف|مصاريف|إيراد|ايراد|مبيعات|بيع|شراء|بمبلغ|مبلغ|شيكل|شواكل|دولار|دولارات)/g,' ').replace(/\s+/g,' ').trim();
 if(!item)item=kind==='sale'?'مبيعات':'مصروف';
 return {kind,item,amount};
}
function handleVoiceFinance(transcript){
 const parsed=parseVoiceFinanceCommand(transcript);
 if(!parsed)return false;
 if(parsed.error){speakVoiceAnswer(parsed.error);return true;}
 const label=parsed.kind==='sale'?'إيراد/مبيعات':'مصروف';
 const question=`سأسجل ${label}: ${parsed.item}، بمبلغ ${parsed.amount}. هل تؤكد الحفظ؟`;
 if(!confirm(question)){speakVoiceAnswer('لم أحفظ شيئاً. ألغيت العملية.');return true;}
 const record={id:uid(),item:parsed.item,amount:parsed.amount,date:today(),notes:'أُدخل بالصوت'};
 (parsed.kind==='sale'?db.sales:db.expenses).push(record);
 if(save())speakVoiceAnswer('تم الحفظ بنجاح.');
 return true;
}
function answerVoiceQuestion(transcript){
 const t=String(transcript||'').trim(),active=activeRabbits(),pending=db.matings.filter(m=>!m.done);
 if(handleVoiceFinance(t))return;
 if(/ابحث عن|دور على|فتش عن/.test(t)){
  const term=t.replace(/.*?(?:ابحث عن|دور على|فتش عن)\s*/,'').trim();
  if(!term||term===t){speakVoiceAnswer('احكي اسم الأرنب أو رقم القفص بعد كلمة ابحث عن.');return}
  $('searchInput').value=term;document.querySelector('[data-tab="rabbits"]')?.click();render();
  const found=active.filter(r=>[r.name,r.cage,r.id].some(v=>String(v||'').toLocaleLowerCase().includes(term.toLocaleLowerCase())));
  speakVoiceAnswer(found.length?`وجدت ${found.length} نتيجة: ${found.slice(0,5).map(r=>r.name).join('، ')}`:`لم أجد أرنباً يطابق ${term}`);return;
 }
 if(/(?:الإناث|أنثى|اناث)/.test(t)){speakVoiceAnswer(`عدد الإناث النشطات ${active.filter(r=>r.sex==='أنثى').length}`);return}
 if(/(?:الذكور|ذكر)/.test(t)){speakVoiceAnswer(`عدد الذكور النشطين ${active.filter(r=>r.sex==='ذكر').length}`);return}
 if(/(?:مريض|مرضى|المريضة|المرضى)/.test(t)){speakVoiceAnswer(`عدد الأرانب المريضة ${active.filter(r=>r.status==='مريض').length}`);return}
 if(/(?:موعد الولادة|الولادات المتوقعة|الحوامل|حامل|التزاوج)/.test(t)){
  const rows=pending.slice().sort((a,b)=>a.due.localeCompare(b.due)).map(m=>`${db.rabbits.find(r=>r.id===m.female)?.name||'أنثى'} موعدها ${m.due}`);
  speakVoiceAnswer(rows.length?`لديك ${rows.length} ولادة متوقعة. ${rows.slice(0,6).join('، ')}`:'لا توجد ولادات متوقعة مسجلة حالياً.');return;
 }
 if(/(?:الصغار|الخلفة|الأرانب الصغيرة)/.test(t)){speakVoiceAnswer(`عدد الصغار المسجلين ${active.filter(r=>!!r.litterId).length}`);return}
 if(/(?:الأرشيف|المؤرشفة|المباع|المتوفى)/.test(t)){speakVoiceAnswer(`عدد الأرانب في الأرشيف ${db.rabbits.filter(r=>r.archived).length}`);return}
 if(/(?:الأقفاص|القفص|عدد الأقفاص)/.test(t)){
  const cages=[...new Set(active.map(r=>String(r.cage||'').trim()).filter(Boolean))];speakVoiceAnswer(cages.length?`عدد الأقفاص المستخدمة ${cages.length}: ${cages.join('، ')}`:'لا توجد أرقام أقفاص مسجلة.');return;
 }
 if(/(?:المبيعات|المصروفات|المصاريف|الربح|الخسارة|الحسابات)/.test(t)){
  const income=db.sales.reduce((n,x)=>n+Number(x.amount||0),0),expense=db.expenses.reduce((n,x)=>n+Number(x.amount||0),0),net=income-expense;
  speakVoiceAnswer(`إجمالي المبيعات ${income.toFixed(2)}، والمصروفات ${expense.toFixed(2)}، والصافي ${net.toFixed(2)}.`);return;
 }
 if(/(?:عدد الأرانب|كم أرنب|إجمالي الأرانب|المجموع)/.test(t)){speakVoiceAnswer(`إجمالي الأرانب النشطة ${active.length}`);return}
 speakVoiceAnswer('سمعتك. يمكنك السؤال عن عدد الأرانب والإناث والذكور والمرضى والصغار والولادات والأقفاص والأرشيف والحسابات، أو قول ابحث عن ثم اسم الأرنب.');
}
let activeVoiceRecognition=null;
$('voiceBtn').onclick=()=>{
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){alert('التعرف على الكلام غير مدعوم في هذا المتصفح. يمكنك استخدام الكتابة كالمعتاد.');return}
 if(activeVoiceRecognition){activeVoiceRecognition.stop();return}
 const rec=new SR();activeVoiceRecognition=rec;rec.lang='ar';rec.interimResults=false;rec.maxAlternatives=1;
 $('voiceBtn').querySelector('span').textContent='أسمعك الآن…';
 rec.onresult=e=>answerVoiceQuestion(e.results?.[0]?.[0]?.transcript||'');
 rec.onerror=e=>{if(e.error!=='no-speech'&&e.error!=='aborted')speakVoiceAnswer('تعذر سماع الصوت. تأكد من إذن الميكروفون وحاول مرة أخرى.')};
 rec.onend=()=>{if(activeVoiceRecognition===rec)activeVoiceRecognition=null;$('voiceBtn').querySelector('span').textContent='احكي معي'};
 try{rec.start()}catch{activeVoiceRecognition=null;$('voiceBtn').querySelector('span').textContent='احكي معي';speakVoiceAnswer('لم أستطع تشغيل الميكروفون. حاول مرة أخرى.')}
};
try{if(localStorage.getItem(KEY)&&!readBackups().length)makeBackup(db,'نسخة أولية من البيانات الموجودة')}catch(e){}
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
render();
