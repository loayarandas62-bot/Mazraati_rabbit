const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');

test('gender summary and mating selectors remain visible and correctly filtered', () => {
  assert.match(html, /<section class="summary-grid"[^>]*aria-label="ملخص المزرعة"/);
  assert.match(html, /<span>الإناث<\/span><strong id="femaleCount">/);
  assert.match(html, /<span>الذكور<\/span><strong id="maleCount">/);
  assert.match(html, /<select id="matingFemale" required><\/select>/);
  assert.match(html, /<select id="matingMale"><\/select>/);
  assert.match(app, /\$\('femaleCount'\)\.textContent=active\.filter\(r=>r\.sex==='أنثى'\)\.length/);
  assert.match(app, /\$\('maleCount'\)\.textContent=active\.filter\(r=>r\.sex==='ذكر'\)\.length/);
  assert.match(app, /\$\('matingFemale'\)\.innerHTML=active\.filter\(r=>r\.sex==='أنثى'\)/);
  assert.match(app, /\$\('matingMale'\)\.innerHTML=.*active\.filter\(r=>r\.sex==='ذكر'\)/);
});

test('gender summary has distinct high-contrast styling and cache version is advanced', () => {
  assert.match(css, /\.summary:nth-child\(2\) span\{color:#a94736\}/);
  assert.match(css, /\.summary:nth-child\(3\) span\{color:#805b0e\}/);
  assert.match(css, /\.summary span\{[^}]*font-weight:800/);
  assert.match(sw, /CACHE_NAME\s*=\s*`\$\{CACHE_PREFIX\}v27`/);
});

test('female production comparison is displayed and sorted by births then kits', () => {
  assert.match(html, /id="femaleProduction"/);
  assert.match(app, /births:history\.length,kits:history\.reduce/);
  assert.match(app, /y\.births-x\.births\|\|y\.kits-x\.kits/);
});

test('dashboard summary cards are keyboard-accessible and open their matching details', () => {
  assert.equal((html.match(/data-summary=/g)||[]).length, 4);
  assert.match(html, /role="button" tabindex="0" data-summary="female"/);
  assert.match(app, /querySelector\([^\n]+\)\.addEventListener\('click'/);
  assert.match(app, /querySelector\([^\n]+\)\.addEventListener\('keydown'/);
  assert.match(app, /summaryFilter==='female'&&r\.sex==='أنثى'/);
  assert.match(app, /summaryFilter==='male'&&r\.sex==='ذكر'/);
  assert.match(css, /\.summary-female\{background:linear-gradient/);
});
