const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');

test('voice assistant answers across farm sections and can search by spoken name', () => {
  assert.match(app, /function answerVoiceQuestion\(transcript\)/);
  for (const phrase of ['الإناث', 'الذكور', 'مريض', 'موعد الولادة', 'الصغار', 'الأرشيف', 'الأقفاص', 'المبيعات', 'ابحث عن']) {
    assert.ok(app.includes(phrase), `voice intent exists: ${phrase}`);
  }
  assert.match(app, /\$\('searchInput'\)\.value=term/);
  assert.match(app, /document\.querySelector\('\[data-tab="rabbits"\]'\)/);
});

test('voice input gives microphone status and handles unavailable or failed recognition', () => {
  assert.match(app, /window\.SpeechRecognition\|\|window\.webkitSpeechRecognition/);
  assert.match(app, /rec\.onerror=/);
  assert.match(app, /rec\.onend=/);
  assert.match(html, /id="voiceBtn"/);
});

test('voice update advances offline cache version', () => {
  assert.match(sw, /CACHE_NAME\s*=\s*`\$\{CACHE_PREFIX\}v27`/);
});

test('voice assistant parses and confirms spoken income and expense before saving', () => {
  assert.match(app, /function parseVoiceFinanceCommand\(transcript\)/);
  assert.match(app, /function handleVoiceFinance\(transcript\)/);
  assert.match(app, /if\(handleVoiceFinance\(t\)\)return/);
  assert.match(app, /if\(!confirm\(question\)\)/);
  assert.match(app, /أُدخل بالصوت/);
  assert.match(app, /٠١٢٣٤٥٦٧٨٩/);
});

test('spoken finance parser extracts expense and sale details and Arabic-Indic digits', () => {
  const vm = require('node:vm');
  const start = app.indexOf('function parseVoiceFinanceCommand(transcript)');
  const end = app.indexOf('function handleVoiceFinance(transcript)', start);
  assert.ok(start >= 0 && end > start);
  const sandbox = {};
  vm.runInNewContext(app.slice(start, end) + '\nthis.parseVoiceFinanceCommand=parseVoiceFinanceCommand;', sandbox);
  assert.deepEqual(JSON.parse(JSON.stringify(sandbox.parseVoiceFinanceCommand('سجل مصروف علف بمبلغ 50 شيكل'))), {kind:'expense', item:'علف', amount:50});
  assert.deepEqual(JSON.parse(JSON.stringify(sandbox.parseVoiceFinanceCommand('سجل بيع أرنب M015 بمبلغ ٢٠'))), {kind:'sale', item:'أرنب M015', amount:20});
  assert.match(sandbox.parseVoiceFinanceCommand('سجل مصروف علف').error, /المبلغ/);
});
