const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

test('editing a rabbit updates the existing record rather than creating a duplicate', () => {
  const handler = app.split('\n').find(line => line.startsWith("$('rabbitForm').onsubmit=")) || '';
  assert.ok(handler, 'rabbit edit/save handler exists');
  assert.match(handler, /if\(rid\)/, 'existing record ID selects edit path');
  assert.match(handler, /db\.rabbits\.find\(x=>x\.id===rid\)/, 'edit finds the original rabbit');
  assert.match(handler, /Object\.assign\(r,data\)/, 'edit updates the same rabbit object');
  assert.match(handler, /else db\.rabbits\.push/, 'only the add path creates a new record');
});

test('cage moves preserve the same rabbit and append a dated from/to history entry', () => {
  const handler = app.split('\n').find(line => line.includes("$('cageForm').onsubmit=")) || '';
  assert.ok(handler, 'cage transfer handler exists');
  assert.match(handler, /r\.cageHistory\.push\(\{from:r\.cage\|\|'',to:next,date\}\)/);
  assert.match(handler, /r\.cage=next/);
  assert.match(handler, /save\(\)\)detail\(r\)/);
  assert.match(app, /if\(det\)detail\(db\.rabbits\.find\(r=>r\.id===det\.dataset\.detail\)\)/, 'details are opened for the existing rabbit record');
});

test('rabbit details show birth-derived age and previous cage transfers', () => {
  assert.match(app, /العمر:<\/b> \$\{age\(r\.birth\)\}/);
  assert.match(app, /من القفص \$\{esc\(x\.from\|\|'—'\)\} إلى \$\{esc\(x\.to\|\|'—'\)\}/);
  assert.match(html, /id="rabbitBirth" type="date"/);
});

test('rabbit details include parents, offspring, mating history and birth history', () => {
  assert.match(app, /const mother=db\.rabbits\.find\(x=>x\.id===r\.parentIds\?\.mother\)/);
  assert.match(app, /const children=db\.rabbits\.filter\(x=>x\.parentIds\?\.mother===r\.id\|\|x\.parentIds\?\.father===r\.id\)/);
  assert.match(app, /const matingHistory=db\.matings\.filter\(m=>m\.female===r\.id\|\|m\.male===r\.id\)/);
  assert.match(app, /const birthHistory=\(r\.birthHistory\|\|\[\]\)/);
  assert.match(app, /سجل التزاوج/);
  assert.match(app, /سجل الولادات/);
  assert.match(app, /الصغار المرتبطون/);
});
